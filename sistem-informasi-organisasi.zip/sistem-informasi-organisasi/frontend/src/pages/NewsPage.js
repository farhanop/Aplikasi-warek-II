import React from 'react';

export default function NewsPage() {
    return (
        <div>
            <h1>News</h1>
            <p>Berita dan pengumuman terbaru.</p>
        </div>
    );
}
