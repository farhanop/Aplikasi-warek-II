import React from 'react';

export default function FacilitiesPage() {
    return (
        <div>
            <h1>Facilities</h1>
            <p>Daftar fasilitas organisasi Anda.</p>
        </div>
    );
}
